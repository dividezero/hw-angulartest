'use strict';

angular.module('myApp')

.controller('MainCtrl', [function() {

}]);